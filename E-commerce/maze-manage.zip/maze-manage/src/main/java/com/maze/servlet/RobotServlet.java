package com.maze.servlet;

import com.maze.dao.RobotDao;
import com.maze.vo.Robot;
import com.maze.vo.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.util.List;
import java.util.UUID;

@WebServlet("/robot")
@MultipartConfig
public class RobotServlet extends HttpServlet {

    private static final String UPLOAD_DIRECTORY = "uploads";
    private static final String IMAGE_PATH = "/image?filename=";
    private RobotDao robotDao;

    @Override
    public void init() throws ServletException {
        super.init();
        robotDao = new RobotDao(); // 初始化 RobotDao
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        String contextPath = request.getContextPath();
        if (action == null) {
            List<Robot> robotList = robotDao.getAllRobots();
            for (Robot robot : robotList) {
                robot.setImage(contextPath + robot.getImage());
            }
            request.setAttribute("robots", robotList);
            request.getRequestDispatcher("/robot.jsp").forward(request, response);
        } else if (action.equals("detail")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Robot robot = robotDao.getRobotById(id);

            if (robot != null) {
                request.setAttribute("robot", robot);
                request.getRequestDispatcher("/detail_robot.jsp").forward(request, response);
            } else {
                response.sendRedirect(contextPath + "/robot");
            }
        }else if (action.equals("add")) {
            request.getRequestDispatcher("/add_robot.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));

            Robot robot = robotDao.getRobotById(id);

            if (robot != null) {
                request.setAttribute("robot", robot);
                request.getRequestDispatcher("/edit_robot.jsp").forward(request, response);
            } else {
                response.sendRedirect(contextPath + "/robot");
            }
        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));

            robotDao.deleteRobot(id);

            response.sendRedirect(contextPath + "/robot");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (action.equals("add")) {
            // 获取表单数据
            String name = getValuePart(request.getPart("name"));
            String videoUrl = getValuePart(request.getPart("videoUrl"));
            // 获取上传的图片
            Part imagePart = request.getPart("image");
            String fileName = imageUpload(imagePart);
            Robot robot = new Robot(user.getId(), name, IMAGE_PATH + fileName, videoUrl);
            robotDao.addRobot(robot);
            response.sendRedirect(request.getContextPath() + "/robot");
        } else if (action.equals("edit")) {
            // 获取表单数据
            String id = getValuePart(request.getPart("id"));
            int robotId = Integer.parseInt(id);
            String name = getValuePart(request.getPart("name"));
            String videoUrl = getValuePart(request.getPart("videoUrl"));
            // 获取上传的图片
            Part imagePart = request.getPart("image");
            String fileName = imageUpload(imagePart);

            Robot robot = new Robot();
            robot.setId(robotId);
            robot.setName(name);
            robot.setImage(IMAGE_PATH + fileName);
            robot.setVideoUrl(videoUrl);
            robotDao.updateRobot(robot);

            // 重定向到机器人列表页面
            response.sendRedirect(request.getContextPath() + "/robot");
        }
    }

    private String imageUpload(Part part) throws IOException {
        // 生成唯一的文件名
        String fileName = UUID.randomUUID().toString() + "-" + getFileName(part);

        // 将文件保存到指定目录
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }
        String filePath = uploadPath + File.separator + fileName;
        part.write(filePath);
        return fileName;
    }

    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] elements = contentDisposition.split(";");
        for (String element : elements) {
            if (element.trim().startsWith("filename")) {
                return element.substring(element.indexOf("=") + 1).trim().replace("\"", "");
            }
        }
        return "";
    }

    private String getValuePart(Part part) throws IOException {
        String value = "";
        if (part != null) {
            InputStream inputStream = part.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            value = stringBuilder.toString();
        }
        return value;
    }
}
