package com.maze.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@WebServlet("/image")
public class ImageServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取图片文件名
        String fileName = request.getParameter("filename");

        if (fileName != null) {
            // 获取ServletContext对象
            javax.servlet.ServletContext context = getServletContext();

            // 构建图片文件的绝对路径
            String filePath = context.getRealPath("/uploads/" + fileName);
            Path imagePath = Paths.get(filePath);

            // 检查文件是否存在
            if (Files.exists(imagePath)) {
                // 读取图片文件并设置响应类型为图片类型
                String mimeType = context.getMimeType(imagePath.toString());
                response.setContentType(mimeType);
                InputStream inputStream = Files.newInputStream(imagePath);

                // 将图片内容写入响应输出流
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    response.getOutputStream().write(buffer, 0, bytesRead);
                }
                inputStream.close();
            } else {
                // 图片文件不存在
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } else {
            // 未提供有效的图片文件名
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
        }
    }
}

