package com.maze.servlet;

import com.maze.dao.ExplorationRecordDao;
import com.maze.vo.ExplorationRecord;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/exploration")
public class ExplorationRecordServlet extends HttpServlet {
    private ExplorationRecordDao recordDao;

    @Override
    public void init() throws ServletException {
        super.init();
        recordDao = new ExplorationRecordDao(); // 初始化 ExplorationRecordDao
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if (action == null) {
            List<ExplorationRecord> recordList = recordDao.getAllExplorationRecords();
            request.setAttribute("records", recordList);
            request.getRequestDispatcher("/exploration.jsp").forward(request, response);
        } else if (action.equals("add")) {
            request.getRequestDispatcher("/add_exploration.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));

            ExplorationRecord record = recordDao.getExplorationRecordById(id);

            if (record != null) {
                request.setAttribute("record", record);
                request.getRequestDispatcher("/edit_exploration.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/exploration");
            }
        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));

            recordDao.deleteExplorationRecord(id);

            response.sendRedirect(request.getContextPath() + "/exploration");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if (action.equals("add")) {
            // 获取表单数据
            int robotId = Integer.parseInt(request.getParameter("robot_id"));
            int explorationTime = Integer.parseInt(request.getParameter("exploration_time"));
            int treasureCount = Integer.parseInt(request.getParameter("treasure_count"));
            ExplorationRecord record = new ExplorationRecord(robotId, explorationTime, treasureCount);
            recordDao.addExplorationRecord(record);
            response.sendRedirect(request.getContextPath() + "/exploration");
        } else if (action.equals("edit")) {
            // 获取表单数据
            int recordId = Integer.parseInt(request.getParameter("id"));
            int robotId = Integer.parseInt(request.getParameter("robot_id"));
            int explorationTime = Integer.parseInt(request.getParameter("exploration_time"));
            int treasureCount = Integer.parseInt(request.getParameter("treasure_count"));

            ExplorationRecord record = new ExplorationRecord(recordId, robotId, explorationTime, treasureCount);
            recordDao.updateExplorationRecord(record);

            // 重定向到探索记录列表页面
            response.sendRedirect(request.getContextPath() + "/exploration");
        }
    }
}
