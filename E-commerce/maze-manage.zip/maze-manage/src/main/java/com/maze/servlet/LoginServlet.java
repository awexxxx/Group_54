package com.maze.servlet;

import com.maze.vo.User;
import com.maze.db.DBConnect;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 在这里进行用户名和密码的验证逻辑
        User user = validateUser(username, password);

        if (user != null) {
            // 如果验证通过，将用户名保存到会话中
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // 重定向到学生列表页面
            response.sendRedirect(request.getContextPath() + "/user");
        } else {
            // 验证不通过，返回登录页面或给出错误提示
            request.setAttribute("errorMsg", "用户名或密码错误");
            request.getRequestDispatcher(request.getContextPath() + "/login.jsp").forward(request, response);
        }
    }

    private User validateUser(String username, String password) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnect.getConnection();
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            resultSet = statement.executeQuery();

            // 如果查询结果有数据，则表示验证通过
            boolean next = resultSet.next();
            if (next) {
                int id = resultSet.getInt("id");
                username = resultSet.getString("username");
                password = resultSet.getString("password");
                User user = new User(id, username, password);
                return user;
            } else {
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            // 关闭数据库资源
            DBConnect.closeResultSet(resultSet);
            DBConnect.closeStatement(statement);
            DBConnect.closeConnection(connection);
        }
    }
}
