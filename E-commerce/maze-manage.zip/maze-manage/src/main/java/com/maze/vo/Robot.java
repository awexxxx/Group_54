package com.maze.vo;

public class Robot {
    private int id;
    private int userId;
    private String username;
    private String name;
    private String image;
    private String videoUrl;

    public Robot() {
    }

    public Robot(int id, int userId, String name, String image, String videoUrl) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.image = image;
        this.videoUrl = videoUrl;
    }

    public Robot(int userId, String name, String image, String videoUrl) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.image = image;
        this.videoUrl = videoUrl;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}

