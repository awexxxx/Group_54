package com.maze.dao;

import com.maze.vo.ExplorationRecord;
import com.maze.db.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExplorationRecordDao {

    public List<ExplorationRecord> getAllExplorationRecords() {
        List<ExplorationRecord> recordList = new ArrayList<>();

        try (Connection conn = DBConnect.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT a.*, b.name as robot_name FROM exploration_records a left join robots b on a.robot_id = b.id")) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int robotId = rs.getInt("robot_id");
                String robotName = rs.getString("robot_name");
                int explorationTime = rs.getInt("exploration_time");
                int treasureCount = rs.getInt("treasure_count");

                ExplorationRecord record = new ExplorationRecord(id, robotId, explorationTime, treasureCount);
                record.setRobotName(robotName);
                recordList.add(record);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return recordList;
    }

    public ExplorationRecord getExplorationRecordById(int recordId) {
        ExplorationRecord record = null;

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM exploration_records WHERE id = ?")) {

            stmt.setInt(1, recordId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    int robotId = rs.getInt("robot_id");
                    int explorationTime = rs.getInt("exploration_time");
                    int treasureCount = rs.getInt("treasure_count");

                    record = new ExplorationRecord(id, robotId, explorationTime, treasureCount);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return record;
    }

    public void addExplorationRecord(ExplorationRecord record) {
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO exploration_records (robot_id, exploration_time, treasure_count) VALUES (?, ?, ?)")) {

            stmt.setInt(1, record.getRobotId());
            stmt.setInt(2, record.getExplorationTime());
            stmt.setInt(3, record.getTreasureCount());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateExplorationRecord(ExplorationRecord record) {
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE exploration_records SET robot_id = ?, exploration_time = ?, treasure_count = ? WHERE id = ?")) {

            stmt.setInt(1, record.getRobotId());
            stmt.setInt(2, record.getExplorationTime());
            stmt.setInt(3, record.getTreasureCount());
            stmt.setInt(4, record.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteExplorationRecord(int recordId) {
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM exploration_records WHERE id = ?")) {

            stmt.setInt(1, recordId);

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
