package com.maze.servlet;

import com.maze.dao.UserDao;
import com.maze.vo.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/user")
public class UserServlet extends HttpServlet {
    private UserDao userDao;

    @Override
    public void init() throws ServletException {
        super.init();
        userDao = new UserDao(); // 初始化 UserDao
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if (action == null) {
            List<User> userList = userDao.getAllUsers();
            request.setAttribute("users", userList);
            request.getRequestDispatcher("/user.jsp").forward(request, response);
        } else if (action.equals("add")) {
            request.getRequestDispatcher("/add_user.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));

            User user = userDao.getUserById(id);

            if (user != null) {
                request.setAttribute("user", user);
                request.getRequestDispatcher("/edit_user.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/user");
            }
        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));

            userDao.deleteUser(id);

            response.sendRedirect(request.getContextPath() + "/user");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if (action.equals("add")) {
            // 获取表单数据
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            User user = new User(username, password);
            userDao.addUser(user);
            response.sendRedirect(request.getContextPath() + "/user");
        } else if (action.equals("edit")) {
            // 获取表单数据
            int userId = Integer.parseInt(request.getParameter("id"));
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            User user = new User(userId, username, password);
            userDao.updateUser(user);

            // 重定向到用户列表页面
            response.sendRedirect(request.getContextPath() + "/user");
        }
    }
}
