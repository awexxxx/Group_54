package com.maze.dao;

import com.maze.vo.Robot;
import com.maze.db.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RobotDao {

    public List<Robot> getAllRobots() {
        List<Robot> robotList = new ArrayList<>();

        try (Connection conn = DBConnect.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT a.*, b.username FROM robots a left join users b on a.user_id = b.id")) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int userId = rs.getInt("user_id");
                String username = rs.getString("username");
                String name = rs.getString("name");
                String image = rs.getString("image");
                String videoUrl = rs.getString("video_url");

                Robot robot = new Robot(id, userId, name, image, videoUrl);
                robot.setUsername(username);
                robotList.add(robot);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return robotList;
    }

    public Robot getRobotById(int robotId) {
        Robot robot = null;

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM robots WHERE id = ?")) {

            stmt.setInt(1, robotId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    int userId = rs.getInt("user_id");
                    String name = rs.getString("name");
                    String image = rs.getString("image");
                    String videoUrl = rs.getString("video_url");

                    robot = new Robot(id, userId, name, image, videoUrl);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return robot;
    }

    public void addRobot(Robot robot) {
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO robots (user_id, name, image, video_url) VALUES (?, ?, ?, ?)")) {

            stmt.setInt(1, robot.getUserId());
            stmt.setString(2, robot.getName());
            stmt.setString(3, robot.getImage());
            stmt.setString(4, robot.getVideoUrl());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateRobot(Robot robot) {
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE robots SET name = ?, image = ?, video_url = ? WHERE id = ?")) {

            stmt.setString(1, robot.getName());
            stmt.setString(2, robot.getImage());
            stmt.setString(3, robot.getVideoUrl());
            stmt.setInt(4, robot.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRobot(int robotId) {
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM robots WHERE id = ?")) {

            stmt.setInt(1, robotId);

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
