package com.maze.vo;

public class ExplorationRecord {
    private int id;
    private int robotId;
    private String robotName;
    private int explorationTime;
    private int treasureCount;

    public ExplorationRecord() {
    }

    public ExplorationRecord(int id, int robotId, int explorationTime, int treasureCount) {
        this.id = id;
        this.robotId = robotId;
        this.explorationTime = explorationTime;
        this.treasureCount = treasureCount;
    }

    public ExplorationRecord(int robotId, int explorationTime, int treasureCount) {
        this.id = id;
        this.robotId = robotId;
        this.explorationTime = explorationTime;
        this.treasureCount = treasureCount;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRobotId() {
        return robotId;
    }

    public void setRobotId(int robotId) {
        this.robotId = robotId;
    }

    public int getExplorationTime() {
        return explorationTime;
    }

    public void setExplorationTime(int explorationTime) {
        this.explorationTime = explorationTime;
    }

    public int getTreasureCount() {
        return treasureCount;
    }

    public void setTreasureCount(int treasureCount) {
        this.treasureCount = treasureCount;
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName;
    }
}

