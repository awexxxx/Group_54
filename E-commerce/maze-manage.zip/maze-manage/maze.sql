/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 50739 (5.7.39)
 Source Host           : 127.0.0.1:3306
 Source Schema         : maze

 Target Server Type    : MySQL
 Target Server Version : 50739 (5.7.39)
 File Encoding         : 65001

 Date: 05/10/2023 15:41:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for exploration_records
-- ----------------------------
DROP TABLE IF EXISTS `exploration_records`;
CREATE TABLE `exploration_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `robot_id` int(11) DEFAULT NULL,
  `exploration_time` int(11) DEFAULT NULL,
  `treasure_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of exploration_records
-- ----------------------------
BEGIN;
INSERT INTO `exploration_records` (`id`, `robot_id`, `exploration_time`, `treasure_count`) VALUES (1, 1, 100, 5);
COMMIT;

-- ----------------------------
-- Table structure for robots
-- ----------------------------
DROP TABLE IF EXISTS `robots`;
CREATE TABLE `robots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of robots
-- ----------------------------
BEGIN;
INSERT INTO `robots` (`id`, `user_id`, `name`, `image`, `video_url`) VALUES (1, 5, 'Robot 1', '/image?filename=7798b35a-0147-49b5-b806-65f0e57d8a65-1696491238133.png', 'https://view.2amok.com/20230718/df5b296066f4e2d376907a3360e59a97.mp4');
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` (`id`, `username`, `password`) VALUES (1, 'user1', '123456');
INSERT INTO `users` (`id`, `username`, `password`) VALUES (5, 'admin', '123456');
INSERT INTO `users` (`id`, `username`, `password`) VALUES (6, 'admin1', '123456');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
